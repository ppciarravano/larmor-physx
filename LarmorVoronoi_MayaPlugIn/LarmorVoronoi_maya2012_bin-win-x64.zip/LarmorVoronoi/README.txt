/*
 * Project name: LarmorVoronoi (Larmor-Physx)
 * Mesh Voronoi shatter Maya Plug-in
 * Version 0.1 (for Maya 2012 64 bits)
 * Released: 2 July 2013
 * Author: Pier Paolo Ciarravano
 * http://www.larmor.com
 *
 * License: This project is released under the Qt Public License (QPL - OSI-Approved Open Source license).
 * http://opensource.org/licenses/QPL-1.0
 *
 * This software is provided 'as-is', without any express or implied warranty.
 * In no event will the authors be held liable for any damages arising from the use of this software.
 *
 */
 
Voronoi Shatter Plug-in in C++ for Maya 2012 (Windows 64bits)
http://code.google.com/p/larmor-physx/

Plug-in Binary build for Maya 2012 Windows 64 bit:
unzip and add the absolute LarmorVoronoi dir path to the PATH system variable and add the plug-in from the Maya menu.

Usage:
Select one or more mesh and use the command: 

LarmorVoronoi [-np NUM_SHATTER_POINTS] [-d true|false]

NUM_SHATTER_POINTS is the number of the voronoi cells (default 10).
If  -d true  the shatter separates the disjointed surfaces (default false).

